package codigo;
//import codigo.Modelo.VO.*;
import codigo.Vista.*;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
        //Consulta2VO.valores();
        new Interfazp();

    }
}
