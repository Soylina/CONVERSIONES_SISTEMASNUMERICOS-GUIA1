package codigo.Controlador;
import codigo.Vista.*;

public class Controlador {
    public static void main( String[] args )
    {
        
        new Interfazp();

    }
}
